# enviro-chat-app
Enviro chat app

## ChatDevOpsEng 
THE APPLICATION SPECIFICATION ON THE AWS CONSOLE LOGIN REQUIREMENTS:

https://612939558689.signin.aws.amazon.com/console

 >>> IMA-UserName : ChatDevOps
 >>>    -Password : DevOps@2023


### CONFIGURATION
IMA infastructure, EC2 aws console service in terms of deployment using docker application
and AWS CLI and Nginx instances. 
Provision a VPC, including a public subnets eu-west-1 region, both Linux(Ubuntu) Hosts.

DevOps Docker : installed Docker and CLi

NginxLoadbalancer instance : Nginx application loader balancer


# DEVOPS-ENGINEER-Assessment
